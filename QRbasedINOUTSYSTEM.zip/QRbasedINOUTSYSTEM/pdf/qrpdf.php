<?php
session_start();
// include '../../functions/dbconn.php';
// include '../../functions/general.php';

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "koha_library";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if (mysqli_connect_error()){
	die('Connect Error('. mysql_connect_errno().')'. mysql_error());
}

require('pdf_js.php');
require_once('phpqrcode/qrlib.php');

class PDF extends FPDF
{
	function Footer()
  {
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Designed By Mr. Omkar Kakeru',0,0,'C');
  }

}

$_SESSION['ip'] = "192.168.1.107";
$ip = $_SESSION['ip'];
$Room_Id = $_GET['Room_Id'];
$url = "http://".$ip."/qrinout/log.php?id=".$Room_Id;

QRcode::png($url, "qrcode.png");

$pdf = new PDF('P','mm','A4');

$pdf->AddPage(); 

$pdf->SetFont("Times", "B", "28");
$pdf->Cell(0, 15, "In out management System", 0, 1, "C");

$pdf->SetFont("Times", "B", "22");
$pdf->Cell(0, 10, $_GET['Room_Name'], 0, 1, "C"); 

$pdf->SetFont("Times", "B", "18");
$pdf->Cell(0, 20, $_GET['Room_Id'], 0, 1, "C"); 

$pdf->Image("qrcode.png",65, 100, 80, 90, "png");

$pdf->output();

?>
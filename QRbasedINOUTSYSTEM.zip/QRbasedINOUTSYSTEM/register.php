<?php
$USN = $_POST['USN'];
$Password = $_POST['Password'];
$Semester = $_POST['Semester'];
$Branch = $_POST['Branch'];

if(!empty($USN) || !empty($Password) || !empty($Semester) || !empty($Branch))
 {
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "koha_library";

    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()){
    	die('Connect Error('. mysql_connect_errno().')'. mysql_error());
    }
    else{
    	$SELECT = "SELECT USN from register where USN=? Limit 1";
    	$INSERT = "INSERT Into register (USN, Password, Semester, Branch) values(?,?,?,?)";


    	$stmt = $conn->prepare($SELECT);
    	$stmt->bind_param("s", $USN);
    	$stmt->execute();
    	$stmt->bind_result($Password);
    	$stmt->store_result();
    	$rnum = $stmt->num_rows;


    	if ($rnum==0)
    	{
    		$stmt->close();

    		$stmt = $conn->prepare($INSERT);
    		$stmt->bind_param("ssis", $USN, $Password, $Semester, $Branch);
    		$stmt->execute(); 
    		echo "New record inserted successfully";
        }
    	 else {
    		echo "Someone already registered using this USN";
    	}
    	$stmt->close();
    	$conn->close();
    
    }
    
}
else
{
	echo "All fields are requied";
	die();
}
?>
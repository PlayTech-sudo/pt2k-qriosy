        <?php
if(isset($_POST['USN']) && isset($_POST['Password']))
{
        

  $USN = $_POST['USN'];
  $Password = $_POST['Password'];

  if($USN == "admin" && $Password == "admin")
  {
      print "Login successfull..!!!";  
        header("refresh:2; url=admin.html");
  }
  if($USN == ($_POST['USN']) && $Password == ($_POST['Password']))
  {
      print "Login successfull..!!!";  
      
  }
 elseif(empty($_POST['USN']))
 {
    print "Enter USN";
 }
 elseif(empty($_POST['Password']))
 {
    print "Enter Password";
 }
 else
 {
  print "Invalid Password or USN";
 }
}

 ?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>login</title>
	<link rel="stylesheet" type="text/css" href="logstyle.css">
</head>
<body>
<form class="box" method="POST" action="login.php">
	<h1>Login</h1>
	<input type="text" name="USN" placeholder="Enter Your USN">
	<input type="password" name="Password" placeholder="Enter Your Password">
	<input type="submit" name="" value="Login">
</body>
</html>
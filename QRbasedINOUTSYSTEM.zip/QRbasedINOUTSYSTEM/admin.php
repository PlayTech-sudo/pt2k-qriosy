<?php
session_start();
$Room_Id = $_POST['Room_Id'];
$Room_Name = $_POST['Room_Name'];
$Description = $_POST['Description'];


if(!empty($Room_Id) || !empty($Room_Name) || !empty($Description))
 {
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "koha_library";

    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()){
    	die('Connect Error('. mysql_connect_errno().')'. mysql_error());
    }
    else{
    	$SELECT = "SELECT Room_Id from room where Room_Id=? Limit 1";
    	$INSERT = "INSERT Into room (Room_Id,Room_Name, Description) values(?,?,?)";


    	$stmt = $conn->prepare($SELECT);
    	$stmt->bind_param("i", $Room_Id);
    	$stmt->execute();
    	$stmt->bind_result($Description);
    	$stmt->store_result();
    	$rnum = $stmt->num_rows;


    	if ($rnum==0)
    	{
    		$stmt->close();

    		$stmt = $conn->prepare($INSERT);
    		$stmt->bind_param("iss",$Room_Id,$Room_Name, $Description);
    		$stmt->execute(); 
    		echo "New room inserted successfully";
        }
    	 else {
    		echo "This room already exists";
    	}
    	$stmt->close();
    	$conn->close();
    
    }
    
}
else
{
	echo "All fields are requied";
	die();
}
session_destroy();
?>



<!DOCTYPE html>
<html>
<head>
    <title>table with database</title>

    <style>
        table{
            border_collapse:collapse;
            width: 100%;
            color: #d96459
            font-family: monospace;
            font-size: 25px;
            text-align: left;
        }

        th{
            background-color: #d96459;
            color: white;

        }
        tr:nth-child(even) {background-color: #f2f2f2}
        
    </style>
</head>
<body>
<table>
    <tr>
        <th>Room_Id</th>
        <th>Room_name</th>
        <th>Description</th>
        <th>QRCODE</th>
     <!-- { -->
        <!-- <a href="qrcode.png" download >Download link</a> -->
<!-- } -->
    </tr>


    <?php
    $conn = mysqli_connect("localhost","root","","koha_library");
    if($conn->connect_error){
        die("Connection failed:". $conn->connect_error);
}
$sql = "Select Room_Id,Room_Name,Description from room";
$result= $conn->query($sql);

if($result->num_rows>0){
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>". $row["Room_Id"]."</td><td>". $row["Room_Name"]."</td><td>".$row["Description"]."</td><td><a href='pdf/qrpdf.php?Room_Id=".$row['Room_Id']."&Room_Name=".$row['Room_Name']."&Room_Id=".$row['Room_Id']."'>Download</a></td></tr>";

        // <td><a target='_blank' href='process/pdf/qrpdf.php?Room_Id=".$row['Room_Id']."&Room_Name=".$row['Room_Name']."&Room_Id=".$row['Room_Id'].">Download</a></td>



    }
    echo "</table>";

}
else{
    echo "0 result";
}
$conn->close();
?>
</table>
</body>
</html>

